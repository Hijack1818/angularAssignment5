package in.co.vwits.model.Exception;

public class StudentNotFoundException extends Exception {
    
     
}
