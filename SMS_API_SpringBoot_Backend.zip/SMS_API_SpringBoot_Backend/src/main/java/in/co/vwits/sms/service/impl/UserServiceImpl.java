package in.co.vwits.sms.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysql.cj.conf.ConnectionUrlParser.Pair;

import in.co.vwits.sms.model.User;
import in.co.vwits.sms.repository.UserRepository;
import in.co.vwits.sms.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository repository;
	
	@Override
	public String save(User user) {
		// TODO Auto-generated method stub
		return repository.save(user)!=null ? "User Save Successfully":"Something Went Wrong";
	}

	@Override
	public String delete(String name) {
		// TODO Auto-generated method stub
		if(this.getUser(name)==null) {
			return "User Is Not Registered";
		}
		repository.deleteById(name);
		return "User Deleted Succesfully";
	}

	@Override
	public String updateUser(User user) {
		if(this.getUser(user.getName())==null) {
			return "User Not Found";
		}
		if(!user.getName().isEmpty() && !user.getPassword().isEmpty()) {
			return repository.save(user)!=null ? "User Updated Successfully":"Something Went Wrong";
		}
		return "Please Fill all details";
	}

	@Override
	public User getUser(String name) {
		return repository.getById(name);
	}

	@Override
	public Pair<Boolean, String> authUser(User user) {
		
		User fetchedUser = this.getUser(user.getName());
		
		System.out.println(fetchedUser);
		
		if(fetchedUser.equals("User Not Found"))return null;
		
		if(fetchedUser.getPassword().equals(user.getPassword())){
			return new Pair<Boolean, String>(true,fetchedUser.getRole());
		}
		return null;
	}

}
