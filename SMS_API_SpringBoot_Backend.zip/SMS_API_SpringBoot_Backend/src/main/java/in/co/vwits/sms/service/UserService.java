package in.co.vwits.sms.service;

import com.mysql.cj.conf.ConnectionUrlParser.Pair;

import in.co.vwits.sms.model.User;

public interface UserService {

	String save(User user);

	String delete(String name);

	String updateUser(User user);

	User getUser(String name);

	Pair<Boolean, String> authUser(User user);

}
